import sys
from .message_room import cli
def run():
    cli()